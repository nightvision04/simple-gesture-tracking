# Inside of __init__.py

import head_controller.db as db
db.setup_db()
