import Camera

Camera.check_video_frame_data_predict()
