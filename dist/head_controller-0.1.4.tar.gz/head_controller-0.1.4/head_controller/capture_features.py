import head_controller.Camera as Camera

Camera.capture_review_submit_labels()
