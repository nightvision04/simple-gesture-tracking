import Camera

Camera.capture_review_submit_labels()
