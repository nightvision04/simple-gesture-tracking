# Inside of __init__.py



import db
db.setup_db()
