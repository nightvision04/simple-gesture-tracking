import head_controller.Camera as Camera
Camera.check_video_frame_data_predict()
